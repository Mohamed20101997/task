<?php
$articles = \App\Models\Article::where('status', 1)->orderBy('date','ASC')->take(5)->get();
?>

<div class="col-sm-12 col-lg-4">
    <!-- start aside section-->
    <div class="aside">
        <div class="row h-100">
            <div class="col-sm-12 px-lg-0 wrap_aside">
                <div class="wrap">
                    <div class="box_social mb-4">
                        <h3>Social Links</h3>
                        <?php
                            $setting = \App\Models\Setting::first();
                               if($setting){
                               $linkes = json_decode($setting->social_links, true);
                               }else{
                                   $linkes =[];
                               }
                        ?>
                        <ul class="list-unstyled mb-0">
                            <?php if(!empty($linkes['facebook'])): ?>
                                <li><a class="hover_el a_hover_none" href="<?php echo e($linkes['facebook']); ?>"><i class="fab fa-facebook"></i></a></li>
                            <?php endif; ?>
                            <?php if(!empty($linkes['twitter'])): ?>
                                <li><a class="hover_el a_hover_none" href="<?php echo e($linkes['twitter']); ?>"><i class="fab fa-twitter"></i></a></li>
                            <?php endif; ?>

                            <?php if(!empty($linkes['instagram'])): ?>
                                <li><a class="hover_el a_hover_none" href="<?php echo e($linkes['instagram']); ?>"><i class="fab fa-instagram"></i></a></li>
                            <?php endif; ?>

                            <?php if(!empty($linkes['youtube'])): ?>
                                <li><a class="hover_el a_hover_none" href="<?php echo e($linkes['youtube']); ?>"><i class="fab fa-youtube"></i></a></li>
                            <?php endif; ?>

                            <?php if(!empty($linkes['linkedin'])): ?>
                                <li><a class="hover_el a_hover_none" href="<?php echo e($linkes['linkedin']); ?>"><i class="fab fa-linkedin"></i></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="latest_posts mb-4">
                        <h3>Latest Posts</h3>
                        <!-- create by sass loop-->
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="wrap_post">
                                <div class="wrap_img"><a href="<?php echo e(route('article.blog',$article->id)); ?>"><img class="def_img" src="<?php echo e($article->image_path); ?>" alt="" srcset=""></a></div>
                                <div class="wrap_info">
                                    <h4><a class="a_hover_none hover_el" href="<?php echo e(route('article.blog',$article->id)); ?>"><?php echo e($article->name); ?></a></h4><span class="date"><?php echo e(date("d-m-Y", strtotime($article->date))); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="new_sletter mb-4">
                    <h2 class="_3d hover_btn"><a class="a_hover_none d-block" href="ask_me.html">3d calculator</a></h2>
                    <h3>Newsletter</h3>
                    <p>Subscribe to our newsletter and get our newest updates right on your email.</p>
                    <form action="<?php echo e(route('setting.news')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <input type="text" name="email" placeholder="Your email address" required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="">
                            <input class="v-mid" type="checkbox" name="agree" required><a class="v-mid a_hover_none" href="#">I agree to the terms & conditions</a>
                            <?php $__errorArgs = ['agree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                        <button class="hover_btn">Subscribe</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- end aside section-->
</div>
<?php /**PATH C:\laragon\www\analog\resources\views/front/_side.blade.php ENDPATH**/ ?>