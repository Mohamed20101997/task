<!DOCTYPE html>
<html lang="en">
<head>

    <title>Analog-Dashboard</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard_files/css/main.css')); ?>">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard_files/plugins/noty/noty.css')); ?>">
    <script src="<?php echo e(asset('dashboard_files/plugins/noty/noty.min.js')); ?>"></script>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">

    <style>
        .toggle-flip input[type="checkbox"] + .flip-indecator {
            width: 110px;
        }
    </style>
</head>
<body class="app sidebar-mini">
<!-- Navbar-->
<?php echo $__env->make('layouts.dashboard._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Sidebar menu-->
<?php echo $__env->make('layouts.dashboard._aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="app-content">
    <?php echo $__env->make('dashboard.partials._confirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('dashboard.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('dashboard.partials._sessions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->yieldContent('content'); ?>

</main>

<!-- Essential javascripts for application to work-->
<script src="<?php echo e(asset('dashboard_files/js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard_files/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard_files/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard_files/js/main.js')); ?>"></script>

<script src="<?php echo e(asset('dashboard_files/js/plugins/select2.min.js')); ?>"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

<?php echo $__env->yieldPushContent('js'); ?>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>

<?php echo $__env->make('dashboard.partials._confirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    $('.select2').select2({
        width: '100%'
    });
</script>
<script>
    $(document).ready(function() {
        $('#summernote ,#summernote1 ,#summernote2').summernote({
            placeholder: 'Description for article',
            height: 200
        });
    });
</script>
</body>
</html>

<?php /**PATH C:\laragon\www\analog\resources\views/layouts/dashboard/app.blade.php ENDPATH**/ ?>