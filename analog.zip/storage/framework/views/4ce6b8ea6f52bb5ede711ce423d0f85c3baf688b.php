

<?php $__env->startSection('content'); ?>
    <!-- Blog entries-->
    <div class="col-lg-8">
        <!-- Nested row for non-featured blog posts-->
        <div class="row">
            <!-- Blog post-->
            <?php if($articles->count() > 0 ): ?>
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Blog post-->
                        <div class="col-lg-6">
                            <div class="card mb-4">
                                <a href="#!"><img id="imgHome" class="card-img-top" src="<?php echo e(image_path($article->image)); ?>" alt="..." /></a>
                                <div class="card-body">
                                    <div class="small text-muted">January 1, 2021</div>
                                    <h2 class="card-title h4"><?php echo e($article->title); ?></h2>

                                    <p id="desHome" class="card-text"><?php echo e(Str::words($article->description ,10,'...')); ?></p>

                                    <a class="btn btn-primary" href="<?php echo e(route('read',$article->id)); ?>">Read more →</a>
                                </div>
                            </div>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="alert alert-primary">No Articles yet ..</div>
            <?php endif; ?>
        </div>
        <!-- Pagination-->
        <nav aria-label="Pagination">
            <hr class="my-0" />
            <ul class="pagination justify-content-center my-4">
                <?php echo e($articles->appends(request()->query())->links()); ?>

            </ul>
        </nav>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\analog\resources\views/front/home.blade.php ENDPATH**/ ?>