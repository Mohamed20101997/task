<?php $__env->startSection('content'); ?>

    <!-- start section slider-->
    <section class="slider">
        <div class="container">
            <div class="row">
                <!-- used grid system bootstap 4-->
                <div class="col-12">
                    <div class="row">
                        <div class="col-sm-12 col-md-6 main_slider mb-3 mb-md-0">
                            <div class="silder_1 owl-carousel">
                                <?php $__currentLoopData = $articleTrend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="wrap_silder"><a class="over_lay_slider" href="#">
                                        </a><span class="name_bdg floating shadow_bdg"><a class="a_hover_none" href="#">Trending</a></span>
                                        <div class="wrap_img"><img width="200px" class="def_img" src="<?php echo e($trend->image_path); ?>" alt=""></div>
                                        <div class="wrap_info_blog"><a class="a_hover_none categore" href="<?php echo e(route('article.blog',$trend->id)); ?>"><?php echo e($trend->category->name); ?></a>
                                            <h2><a class="a_hover_none" href="<?php echo e(route('article.blog',$trend->id)); ?>"><?php echo e($trend->name); ?></a></h2>
                                            <ul class="list-unstyled mb-0 wrap_state">
                                                <li><span class="date"><?php echo e(date("M d , Y", strtotime($trend->date))); ?></span></li>
                                                <li>
                                                    <!-- use FontAwsome Pro or Free-->
                                                    <span class="views"><i class="fas fa-chart-bar"></i> <?php echo e($trend->view); ?> views</span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <!-- used grid system bootstap 4-->
                        <div class="col-sm-12 col-md-6">
                            <div class="row">
                                <!-- used grid system bootstap 4-->
                                <div class="col-sm-12 col-lg-6 mb-3 px-md-0 pr-lg-2 wrap_sub_slider_1">
                                    <!-- create by lib owl-carousel-->
                                    <div class="silder_1 sub_slider owl-carousel">
                                       <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="wrap_silder"><a class="over_lay_slider" href="<?php echo e(route('article.blog',$feature->id)); ?>"></a><span class="name_bdg floating shadow_bdg"><a class="a_hover_none" href="list_category.html">Featured</a></span>

                                                <img height="300px" src="<?php echo e($feature->image_path); ?>" alt="">

                                            <div class="wrap_info_blog"><a class="a_hover_none categore" href="<?php echo e(route('article.blog',$feature->id)); ?>"><?php echo e($feature->category->name); ?></a>
                                                <h2><a class="a_hover_none" href="<?php echo e(route('article.blog',$feature->id)); ?>"><?php echo e($feature->name); ?></a></h2>
                                                <ul class="list-unstyled mb-0 wrap_state">
                                                    <li><span class="date"><?php echo e(date("M d , Y", strtotime($feature->date))); ?></span></li>
                                                    <li>
                                                        <!-- use FontAwsome Pro or Free-->
                                                        <span class="views"><i class="fas fa-chart-bar"></i> <?php echo e($feature->view); ?> views</span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <!-- used grid system bootstap 4-->
                                <div class="col-sm-12 col-lg-6 mb-3 px-md-0 pl-lg-2 wrap_sub_slider_2">
                                    <!-- create by lib owl-carousel-->
                                    <div class="silder_1 sub_slider owl-carousel">
                                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="wrap_silder"><a class="over_lay_slider" href="<?php echo e(route('article.blog',$article->id)); ?>">
                                                </a><span class="name_bdg floating shadow_bdg"><a class="a_hover_none" href="list_category.html">Recent</a></span>
                                                <img height="300px"  src="<?php echo e($article->image_path); ?>" alt="">
                                            <div class="wrap_info_blog"><a class="a_hover_none categore" href="a<?php echo e(route('article.blog',$article->id)); ?>"><?php echo e($article->category->name); ?></a>
                                                <h2><a class="a_hover_none" href="<?php echo e(route('article.blog',$article->id)); ?>"><?php echo e($article->name); ?></a></h2>
                                                <ul class="list-unstyled mb-0 wrap_state">
                                                    <li><span class="date"><?php echo e(date("M d ,Y", strtotime($article->date))); ?></span></li>
                                                    <li>
                                                        <!-- use FontAwsome Pro or Free-->
                                                        <span class="views"><i class="fas fa-chart-bar"></i> <?php echo e($article->view); ?> views</span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <!-- used grid system bootstap 4-->
                                <div class="col-sm-12 px-md-0 wrap_sub_slider_3">
                                    <!-- create by lib owl-carousel-->
                                    <div class="silder_1 sub_slider owl-carousel">
                                        <!-- create by sass loop-->
                                        <div class="wrap_silder"><a class="over_lay_slider" href="ask_me.html"></a><span class="name_bdg floating shadow_bdg"><a class="a_hover_none" href="list_category.html">3d calculator</a></span>
                                            <div class="wrap_img"><a href="ask_me.html"><img class="def_img" src="<?php echo e(asset('front/image/s_3.jpg')); ?>" alt=""></a></div>
                                            <div class="wrap_info_blog"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end section slider-->

    <!-- start section ad-google-->
    <section class="ads">
        <div class="container">
            <div class="wrap_ads"></div>
        </div>
    </section>
    <!-- start section ad-google-->

    <!-- start section trending_store-->
    <section class="trending_blogs">
        <div class="container">
            <div class="row">
                <!-- used grid system bootstap 4-->
                <div class="col-12 title">
                    <h2>Trending Stories</h2>
                    <p class="mb-0">Don't miss to check out our most popular posts</p>
                </div>
                <!-- used grid system bootstap 4-->
                <div class="col-12 sliders_blogs owl-carousel owl-theme">

                    <?php $__currentLoopData = $trends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="wrap_blog">
                        <div class="wrap_img">
                            <a href="<?php echo e(route('article.blog',$trend->id)); ?>"><img height="150px" src="<?php echo e($trend->image_path); ?>" alt="<?php echo e($trend->name); ?>"></a>
                        </div>
                        <div class="wrap_info_blog"><a class="categore" href="<?php echo e(route('article.list',$trend->category_id)); ?>"><?php echo e($trend->category->name); ?></a>
                            <h2><a href="<?php echo e(route('article.blog',$trend->id)); ?>"><?php echo e($trend->category->name); ?></a></h2>
                            <ul class="list-unstyled mb-0 wrap_state">
                                <li><span class="date"><?php echo e(date("M d ,Y", strtotime($trend->date))); ?></span></li>
                                <li>
                                    <!-- use FontAwsome Pro or Free-->
                                    <span class="views"><i class="fas fa-chart-bar"></i> <?php echo e($trend->view); ?> views</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    <!-- end section trending_store-->

    <!-- start section ad-google-->
    <section class="ads">
        <div class="container">
            <div class="wrap_ads"></div>
        </div>
    </section>
    <!-- start section ad-google-->

    <!-- start section list bloger-->
    <section class="list_bloger">
        <div class="container">
            <div class="row">
                <!-- used grid system bootstap 4-->
                <div class="col-sm-12 col-md-12 col-lg-8">

                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="wrap_blog">
                            <div class="wrap_img"><span class="name_bdg">Pinned</span><a href="<?php echo e(route('article.blog',$post->id)); ?>"><img class="def_img" src="<?php echo e($post->image_path); ?>"  alt="" srcset=""></a></div>
                            <div class="wrap_info"><a class="categore" href="<?php echo e(route('article.list',$post->category_id)); ?>"><?php echo e($post->category->name); ?></a>
                                <h2 class="mb-0"><a class="a_hover_none hover_el" href="<?php echo e(route('article.blog',$post->id)); ?>"><?php echo e($post->name); ?></a></h2>
                                <ul class="list-unstyled mb-0 wrap_state">
                                    <li><span>By </span><a class="a_hover_none" href="#"><?php echo e($post->author->name); ?></a></li>
                                    <li><span class="date"><?php echo e(date("M d ,Y", strtotime($article->date))); ?></span></li>
                                    <li>
                                        <span class="views"><i class="fas fa-chart-bar"></i> <?php echo e($post->view); ?> views</span>
                                    </li>
                                </ul>
                                <p class="mb-0"><?php echo e(Str::limit(strip_tags($post->description),81,'...')); ?></p>
                                <!-- use FontAwsome Pro or Free-->
                                <a class="read_more a_hover_none" href="<?php echo e(route('article.blog',$post->id)); ?>"> read more <i class="fas fa-long-arrow-alt-right"></i></a>
                            </div>
                        </div>
                        <div class="clear_fix"></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('article.featured')); ?>"><div class="load_more mb-4"><span class="hover_btn">load more posts</span></div></a>
                </div>

                <?php echo $__env->make('front._side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </section>
    <!-- end section list bloger-->



















<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\analog\resources\views/front/home.blade.php ENDPATH**/ ?>