<?php $__env->startSection('content'); ?>

    <h1>Articles</h1>

    <ul class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('welcome')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item" active>Articles</li>
    </ul>


    <div class="row">
        <div class="col-md-12">
            <div class="tile mb-4">
                <form action="">
                    <div class="row">

                        <div class="col-4">
                            <div class="form-group">
                                <input type="text" autofocus name="search" placeholder="search" class="form-control" value="<?php echo e(request()->search); ?>">
                            </div>
                        </div>

                        <div class="col-4">
                            <select name="category" class="form-control">
                                <option value="">All Categories</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e(request()->category_id == $category->id ? 'selected' : ''); ?>> <?php echo e($category->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <button type="submit" class="btn btn-success"><i class="fa fa-search"></i>Search</button>
                            <a href="<?php echo e(route('article.create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i>Add</a>
                        </div> <!-- end of col 12 -->

                    </div> <!-- end of row -->

                </form> <!-- end of form -->

                <div class="row">
                    <div class="col-md-12">
                        <?php if(count($articles) > 0): ?>
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Author</th>
                                    <th>category</th>
                                    <th>Image</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index+1); ?></td>
                                        <td><?php echo e($article->name); ?></td>
                                        <td><?php echo e($article->author->name); ?></td>
                                        <td><?php echo e($article->category->name); ?></td>
                                        <td>
                                            <img src="<?php echo e(image_path($article->image)); ?>" id="blah" width="50px" alt="your image" height="50px">
                                        </td>

                                        <td>
                                            <span class="badge bg-primary p-2 text-white"><?php echo e(date("d-m-y:H-m-s", strtotime($article->date))); ?></span>
                                        </td>

                                        <td><span class="badge bg-secondary p-2 text-white"><?php echo e($article->status($article->status)); ?></span></td>

                                        <td>
                                            <a href="<?php echo e(route('article.edit', $article->id)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i>Edit</a>

                                            <form method="post" action=<?php echo e(route('article.destroy', $article->id)); ?> style="display:inline-block">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm delete"><i class="fa fa-trash"></i>Delete</button>
                                            </form> <!-- end of form -->
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <?php echo e($articles->appends(request()->query())->links()); ?>


                        <?php else: ?>
                            <h3 class="alert alert-info text-center" style="font-weight: 400"><i class="fa fa-exclamation-triangle"></i> Sorry no records found</h3>
                        <?php endif; ?>
                    </div> <!-- end of col-md-12 -->
                </div> <!-- end of row -->

            </div> <!-- end of tile -->

        </div> 
    </div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\analog\resources\views/dashboard/articles/index.blade.php ENDPATH**/ ?>