
<?php
    $latest     = \App\Models\Article::where('status', 1)->orderBy('date','ASC')->take(2)->get();
    $header     = \App\Models\Article::where('status', 1)->orderBy('date','ASC')->take(4)->get();
    $tags       = \App\models\Tag::with('articles')->take(20)->get();
    $Categories   =  \App\Models\Category::get();
   $setting = \App\Models\Setting::first();
    if($setting){
    $linkes = json_decode($setting->social_links, true);
    }else{
        $linkes =[];
    }
?>

<?php echo $__env->make('layouts.front._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.partials._sessions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('layouts.front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\laragon\www\analog\resources\views/layouts/front/app.blade.php ENDPATH**/ ?>