
    <div class="modal-dialog  modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Comment for : <?php echo e($comment->name); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="wrap_post">
                    <div class="wrap_img"><img height= '200px' class="def_img" src="<?php echo e($comment->article->image_path); ?>" alt="">
                    </div>
                    <div class="wrap_info">
                        <h4><?php echo e($comment->article->name); ?>

                        </h4><span class="date"><?php echo e(date("M d,Y", strtotime($comment->article->date))); ?></span>
                    </div>
                </div>
                <div class="wrap_post p-3">
                    <h3><?php echo e($comment->name); ?></h3>
                    <span><?php echo e($comment->created_at->toFormattedDateString()); ?></span>
                    <p><?php echo e($comment->comment); ?></p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>

<?php /**PATH C:\laragon\www\analog\resources\views/dashboard/comments/model.blade.php ENDPATH**/ ?>