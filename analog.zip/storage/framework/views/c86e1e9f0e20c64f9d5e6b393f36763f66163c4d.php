

<?php $__env->startSection('content'); ?>

    <!-- start section artical_blog-->
    <section class="artical_blog">
        <div class="container">
            <div class="row">
                <!-- use grid system bootstrap 4-->
                <div class="col-sm-12 col-lg-8">
                    <div class="artical">
                        <div class="wrap_img"><img class="def_img" src="<?php echo e($article->image_path); ?>" alt=""></div>
                        <div class="wrap_info"><a class="categore a_hover_none" href="list_category.html"><?php echo e($article->category->name); ?></a>
                            <h2><?php echo e($article->name); ?></h2>
                            <ul class="list-unstyled wrap_state">
                                <li><span>By </span><a class="a_hover_none" href="user_profile.html"><?php echo e($article->author->name); ?></a></li>
                                <li><span class="date"><?php echo e(date("M d,Y", strtotime($article->date))); ?></span></li>
                                <li>
                                    <!-- use FontAwsome Pro or Free-->
                                    <span class="views"><i class="fas fa-chart-bar"></i> <?php echo e($article->view); ?> views</span>
                                </li>
                            </ul>
                            <p><?php echo $article->description; ?></p>
                            <div class="tags">
                                <ul class="list-unstyled">
                                    <?php $__currentLoopData = $article->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="list_category.html"><?php echo e($tag->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <div class="footer">
                            <ul class="list-unstyled mb-0 wrap_state">
                                <li>
                                    <!-- use FontAwsome Pro or Free-->
                                    <a class="comment hover_el a_hover_none" href="#"><i class="far fa-comment"></i> <?php echo e($commentsCount); ?> comments</a>
                                </li>
                                <li>
                                    <!-- use FontAwsome Pro or Free-->
                                    <span class="views"><i class="fas fa-chart-bar"></i> <?php echo e($article->view); ?> views</span>
                                </li>
                            </ul>
                            <ul class="list-unstyled mb-0 wrap_social">
                                <li>Share:</li>
                                <li><a class="a_hover_none hover_el" href="#"><i class="fab fa-facebook"></i></a></li>
                                <li><a class="a_hover_none hover_el" href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a class="a_hover_none hover_el" href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                <li><a class="a_hover_none hover_el" href="#"><i class="far fa-envelope"></i></a></li>
                            </ul>
                        </div>
                        <div class="auther">
                            <div class="wrap_user"><a href="user_profile.html"><img class="def_img" src="<?php echo e($article->author->image_path); ?>" alt="user"></a></div>
                            <div class="wrap_user_content">
                                <h4><a class="a_hover_none hover_el" href="user_profile.html"><?php echo e($article->author->name); ?></a></h4>
                                <p><?php echo $article->author->brief; ?></p>
                                <ul class="list-unstyled mb-0 wrap_social">
                                    <li><a class="a_hover_none hover_el" href="#"><i class="fas fa-globe-asia"></i></a></li>
                                    <li><a class="a_hover_none hover_el" href="#"><i class="fab fa-facebook"></i></a></li>
                                    <li><a class="a_hover_none hover_el" href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a class="a_hover_none hover_el" href="#"><i class="fab fa-instagram"></i></a></li>
                                    <li><a class="a_hover_none hover_el" href="#"><i class="fab fa-youtube"></i></a></li>
                                    <li><a class="a_hover_none hover_el" href="#"><i class="fab fa-linkedin"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="m_page">
                            <div class="row">

                                <?php if(isset($previous->name)): ?>
                                <div class="col-sm-12 col-md-6 prev_post text-left text-md-left"><a class="a_hover_none" href="<?php echo e(route('article.blog',$previous->id)); ?>"><span>Prev Post</span>
                                        <h5 class="hover_el"><?php echo e($previous->name); ?></h5></a></div>
                                <?php endif; ?>

                                <?php if(isset($next->name)): ?>
                                    <div class="col-sm-12 col-md-6 next_post text-left text-md-right">
                                        <a class="a_hover_none" href="<?php echo e(route('article.blog',$next->id)); ?>"><span>next Post</span>
                                            <h5 class="hover_el"><?php echo e($next->name); ?></h5></a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="related_Posts">
                            <h2>Related Posts</h2>
                            <div class="sliders_posts owl-carousel">
                                <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="wrap_blog">
                                    <div class="wrap_img"><img class="def_img" src="<?php echo e($relate->image_path); ?>" alt=""></div>
                                    <div class="wrap_info_blog"><a class="categore" href="list_category.html"><?php echo e($relate->category->name); ?></a>
                                        <h2><a href="<?php echo e(route('article.blog',$relate->id)); ?>"><?php echo e($relate->name); ?></a></h2>
                                        <ul class="list-unstyled mb-0 wrap_state">
                                            <li><span class="date"><?php echo e(date("M d,Y", strtotime($relate->date))); ?></span></li>
                                        </ul>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="type_comment">
                            <h3>Leave a comment</h3>
                            <p>Your email address will not be published. Required fields are marked</p>
                            <form action="<?php echo e(route('article.comment')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <div class="row">
                                    <!-- use grid system bootstrap 4-->
                                    <input type="hidden" name="article_id" value="<?php echo e($article->id); ?>">
                                    <div class="col-12 wrap_textarea">
                                        <textarea name="comment" rows="4" placeholder="Type your comment"></textarea>
                                        <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <!-- use grid system bootstrap 4-->
                                    <div class="col-sm-12 col-md-6 col-lg-4 wrap_input">
                                        <input name="name" type="text" placeholder="Name*">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <!-- use grid system bootstrap 4-->
                                    <div class="col-sm-12 col-md-6 col-lg-4 wrap_input">
                                        <input name="email" type="email" placeholder="Email*">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <!-- use grid system bootstrap 4-->
                                    <div class="col-sm-12 col-lg-4 wrap_input">
                                        <input name="website" type="url" placeholder="Website">
                                        <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <!-- use grid system bootstrap 4-->
                                    <div class="col-12">
                                        <label for="a_1">
                                            <input type="checkbox" name="save" id="a_1"><span>Save my name, email, and website in this browser for the next time I comment.</span>
                                        </label>
                                    </div>
                                    <div class="col-12">
                                        <button class="btn hover_btn">Post Comment</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="auther">
                            <div class="wrap_user"><i class="fa fa-comments-alt fa-1x"></i></div>
                            <div class="wrap_user_content">
                                <h4><?php echo e($comment->name); ?></h4>
                                <span><?php echo e($comment->created_at->toFormattedDateString()); ?></span>
                                <p><?php echo e($comment->comment); ?></p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($comments->appends(request()->query())->links()); ?>

                    </div>
                </div>
                <?php echo $__env->make('front._side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </section>
    <!-- end section artical_blog-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\analog\resources\views/front/blog.blade.php ENDPATH**/ ?>