<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
  <div class="app-sidebar__user">
    <div>
      <p class="app-sidebar__user-name"><?php echo e(auth()->user()->name); ?></p>
      <p class="app-sidebar__user-designation"><?php echo e(auth()->user()->email); ?></p>
    </div>
  </div>
  <ul class="app-menu">

  <li><a class="app-menu__item  <?php echo e(\Request::route()->getName() == 'category.index' ? 'active' : ''); ?>" href="<?php echo e(route('category.index')); ?>"><i class="app-menu__icon fa fa-list-alt"></i><span class="app-menu__label">Categories</span></a></li>
  <li><a class="app-menu__item  <?php echo e(\Request::route()->getName() == 'tag.index' ? 'active' : ''); ?>" href="<?php echo e(route('tag.index')); ?>"><i class="app-menu__icon fa fa-tag"></i><span class="app-menu__label">tags</span></a></li>
  <li><a class="app-menu__item  <?php echo e(\Request::route()->getName() == 'article.index' ? 'active' : ''); ?>" href="<?php echo e(route('article.index')); ?>"><i class="app-menu__icon fa fa-newspaper-o"></i><span class="app-menu__label">Articles</span></a></li>

  </ul>
</aside>
<?php /**PATH C:\laragon\www\analog\resources\views/layouts/dashboard/_aside.blade.php ENDPATH**/ ?>