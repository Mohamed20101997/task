<?php $__env->startSection('content'); ?>

    <h1>Contacts</h1>

    <ul class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('welcome')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item" active>Contacts</li>
    </ul>


    <div class="row">
        <div class="col-md-12">

            <div class="tile mb-4">
                <form action="">
                    <div class="row">

                    </div> <!-- end of row -->
                </form> <!-- end of form -->
                <div class="row">
                    <div class="col-md-12">
                        <?php if($contacts->count() > 0): ?>
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>email</th>
                                    <th>subject</th>
                                    <th>message</th>
                                    <th>Action</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index+1); ?></td>
                                        <td><?php echo e($contact->name); ?></td>
                                        <td><?php echo e($contact->email); ?></td>
                                        <td><?php echo e($contact->subject); ?></td>
                                        <td><?php echo e($contact->message); ?></td>
                                        <td>
                                            <form method="post" action=<?php echo e(route('setting.contact.delete', $contact->id)); ?> style="display:inline-block">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('post'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm delete"><i class="fa fa-trash"></i></button>
                                            </form> <!-- end of form -->
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <?php echo e($contacts->appends(request()->query())->links()); ?>


                        <?php else: ?>
                            <h3 class="alert alert-info text-center" style="font-weight: 400"><i class="fa fa-exclamation-triangle"></i> Sorry no records found</h3>
                        <?php endif; ?>
                    </div> <!-- end of col-md-12 -->
                </div> <!-- end of row -->

            </div> <!-- end of tile -->

        </div> 
    </div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\analog\resources\views/dashboard/contact/index.blade.php ENDPATH**/ ?>