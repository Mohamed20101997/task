<!-- start floating btn contact us-->
<button class="btn btn_floating hover_btn"><i class="fas fa-user-headset"></i></button>
<!-- end floating btn contact us-->

<!-- start contact us-->
<div class="contact_us" tabIndex="-1">
    <div class="wrap_contact">
        <p>You may easily set up a contact form with plugin that fully supported by Berg. Below is the working form demo:</p>
        <form action="<?php echo e(route('setting.contact')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <!-- create by pugjs loop-->
            <div class="wrap_filde">
                <label class="req" for="#1">Name</label>
                <input type="text" name="name" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <!-- create by pugjs loop-->
            <div class="wrap_filde">
                <label class="req" for="#2">E-Mail</label>
                <input type="email" name="email" required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <!-- create by pugjs loop-->
            <div class="wrap_filde">
                <label class="req"  for="#3">Subject</label>
                <input type="text" name="subject" required>
                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="wrap_filde">
                <label class="req" for="">Message</label>
                <textarea name="message" cols="40" rows="5" placeholder="Type your message" required></textarea>
                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button class="btn">Send</button>
        </form>
    </div>
</div>
<!-- end contact us-->
<!-- start footer-->
<footer>
    <div class="container">
        <div class="row">
            <!-- used grid system botstrap 4-->
            <div class="col-sm-12 col-md-12 col-lg-4 about_site order-3 order-lg-1">
                <div class="wrap_logo">
                    <a class="a_hover_none" href="<?php echo e(route('home')); ?>">
                        <img class="def_img" src="<?php echo e($setting->image_path); ?>" alt="logo" srcset="">
                        <span><?php echo e($setting->site_name); ?></span>
                    </a>

                </div>
                <p class="mb-0"><?php echo e($setting->description); ?></p>
                <ul class="list-unstyled mb-0">
                    <!-- create by sass loop-->
                    <!-- use icon fontAwsome 5-->
                    <?php if(!empty($linkes['facebook'])): ?>
                        <li><a class="a_hover_none hover_el" href="<?php echo e($linkes['facebook']); ?>"><i class="fab fa-facebook"></i></a></li>
                    <?php endif; ?>
                    <?php if(!empty($linkes['twitter'])): ?>
                        <li><a class="a_hover_none hover_el" href="<?php echo e($linkes['twitter']); ?>"><i class="fab fa-twitter"></i></a></li>
                    <?php endif; ?>

                    <?php if(!empty($linkes['instagram'])): ?>
                        <li><a class="a_hover_none hover_el" href="<?php echo e($linkes['instagram']); ?>"><i class="fab fa-instagram"></i></a></li>
                    <?php endif; ?>

                    <?php if(!empty($linkes['youtube'])): ?>
                        <li><a class="a_hover_none hover_el" href="<?php echo e($linkes['youtube']); ?>"><i class="fab fa-youtube"></i></a></li>
                    <?php endif; ?>

                    <?php if(!empty($linkes['linkedin'])): ?>
                        <li><a class="a_hover_none hover_el" href="<?php echo e($linkes['linkedin']); ?>"><i class="fab fa-linkedin"></i></a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <!-- used grid system botstrap 4-->
            <div class="col-sm-12 col-md-6 col-lg-4 lastes_post order-1 order-lg-2">
                <h3>Latest Posts</h3>

                <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="wrap_post">
                    <div class="wrap_img"><a href="<?php echo e(route('article.blog',$lat->id)); ?>">
                            <img class="def_img" src="<?php echo e($lat->image_path); ?>" alt=""></a>
                    </div>
                    <div class="wrap_info">
                        <h4><a class="a_hover_none hover_el" href="<?php echo e(route('article.blog',$lat->id)); ?>"><?php echo e($lat->name); ?></a></h4><span class="date"><?php echo e(date("M d,Y", strtotime($lat->date))); ?></span>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <h3>popular questions</h3>
                <!-- create by sass loop-->
                <div class="wrap_post">
                    <div class="wrap_img"><a href="view_question.html"><img class="def_img ques" src="<?php echo e(asset('front/image/avatar.png')); ?>" alt=""></a></div>
                    <div class="wrap_info">
                        <h4><a class="a_hover_none hover_el" href="view_question.html">Options for Your Activity Tracking Smart Watch</a></h4><span class="date">June 4, 2019              </span>
                    </div>
                </div>
                <div class="wrap_post">
                    <div class="wrap_img"><a href="view_question.html"><img class="def_img ques" src="<?php echo e(asset('front/image/avatar.png')); ?>" alt=""></a></div>
                    <div class="wrap_info">
                        <h4><a class="a_hover_none hover_el" href="view_question.html">Options for Your Activity Tracking Smart Watch</a></h4><span class="date">June 4, 2019              </span>
                    </div>
                </div>
            </div>
            <!-- used grid system botstrap 4-->
            <div class="col-sm-12 col-md-6 col-lg-4 tags order-2 order-lg-3">
                <h3>Tags</h3>
                <ul class="list-unstyled">
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count($tag->articles) > 0): ?>
                            <li><a class="a_hover_none" href="<?php echo e(route('article.list.tag',$tag->id)); ?>"><?php echo e($tag->name); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="hr"></div>
    <div class="container">
        <div class="row">
            <!-- used grid system botstrap 4-->
            <div class="col-sm-12 pre_footer">
                <ul class="list-unstyled d-none d-md-block">
                    <!-- create by sass loop-->
                    <li><a class="a_hover_none hover_el" href="<?php echo e(route('setting.term')); ?>">Terms &amp; Conditions</a></li>
                    <li><a class="a_hover_none hover_el" href="<?php echo e(route('setting.privacy')); ?>">Privacy Policy</a></li>
                    <li><a class="a_hover_none hover_el" href="<?php echo e(route('setting.about')); ?>">About</a></li>
                    <li><a class="a_hover_none hover_el" href="#">3d calculator</a></li>
                    <li><a class="a_hover_none hover_el" href="#">community</a></li>
                </ul>
                <div class="copy_right text-left text-md-center">© 2021 Techunique. All rights reserved.</div>
            </div>
        </div>
    </div>
</footer>
<!-- end footer-->
<script src="<?php echo e(asset('front/js/popper.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/jQuery.tagify.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/tagify.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/jquery.nicescroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\analog\resources\views/layouts/front/footer.blade.php ENDPATH**/ ?>