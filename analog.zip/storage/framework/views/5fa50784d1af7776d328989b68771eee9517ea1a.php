

<?php $__env->startSection('content'); ?>

    <h1>Comments</h1>

    <ul class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('welcome')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item" active>Comments</li>
    </ul>


    <div class="row">
        <div class="col-md-12">

            <div class="tile mb-4">
                <form action="">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <input type="text" autofocus name="search" placeholder="search" class="form-control" value="<?php echo e(request()->search); ?>">
                            </div>
                        </div><!-- end of col 4 -->

                        <div class="col-4">
                            <button type="submit" class="btn btn-success"><i class="fa fa-search"></i>Search</button>
                        </div> <!-- end of col 12 -->

                    </div> <!-- end of row -->
                </form> <!-- end of form -->
                <div class="row">
                        <?php if($comments->count() > 0): ?>
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>email</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index+1); ?></td>
                                        <td><?php echo e($comment->name); ?></td>
                                        <td><?php echo e($comment->email); ?></td>

                                        <td>
                                            <a data-url="<?php echo e(route('comment.show', $comment->id)); ?>" data-id="<?php echo e($comment->id); ?>" id="show" class="btn btn-warning btn-sm"><i class="fa fa-eye"></i></a>
                                            <form method="post" action=<?php echo e(route('comment.destroy', $comment->id)); ?> style="display:inline-block">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm delete"><i class="fa fa-trash"></i></button>
                                            </form> <!-- end of form -->
                                        </td>
                                    </tr>
                                        <div class="modal fade" id="model_<?php echo e($comment->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <?php echo e($comments->appends(request()->query())->links()); ?>


                        <?php else: ?>
                            <h3 class="alert alert-info text-center" style="font-weight: 400"><i class="fa fa-exclamation-triangle"></i> Sorry no records found</h3>
                        <?php endif; ?>
                    </div> <!-- end of col-md-12 -->
                </div> <!-- end of row -->

            </div> <!-- end of tile -->

        </div> 
    </div> 
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
<script>
    //for show extra model
    $(document).on('click', '#show', function (event) {
        event.preventDefault();
        let url = $(this).data('url');
        let id = $(this).data('id');
        $.ajax({
            url: url,
            data: {
                id: id,
            },
            method: 'GET',
            success: function (data) {
                $('#model_' + id).html(data);
                $('#model_' + id).modal('show');
            },
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\analog\resources\views/dashboard/comments/index.blade.php ENDPATH**/ ?>