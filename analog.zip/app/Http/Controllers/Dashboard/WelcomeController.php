<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class WelcomeController extends Controller
{

    public function index()
    {
        return view('dashboard.welcome');

    } //end of index

} //end of controller
