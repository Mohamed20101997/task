@extends('layouts.dashboard.app')

@section('content')

<h1>Articles</h1>

    <ul class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ route('welcome') }}">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="{{ route('article.index') }}">Articles</a></li>
        <li class="breadcrumb-item" active>edit</li>
    </ul>


    <div class="row">
        <div class="col-md-12">
            <div class="tile mb4">
                <form class="form"  method="post" action="{{ route('article.update', $article->id) }}" enctype="multipart/form-data">
                    @csrf
                    @method('put')
                    <input name="id" value="{{$article->id}}" type="hidden">
                    <div class="row">
                        <div class="col-md-4">
                            {{-- title --}}
                            <div class="form-group">
                                <label>Title</label>
                                <input type="text" name="title" class="form-control" value="{{ old('title', $article->name) }}">
                                @error('title')
                                <div class="text-danger">{{$message}}</div>
                                @enderror
                            </div>
                        </div>{{-- end of col title --}}

                        <div class="col-md-4">
                            {{-- category --}}
                            <div class="form-group">
                                <label>Category</label>
                                <select name="category_id" class="form-control select2">
                                    @foreach ($categories as $category)
                                        <option {{ old('category_id',$article->category_id) == $category->id ? "selected" : "" }}  value="{{ $category->id }}">{{ $category->name }}</option>
                                    @endforeach
                                </select>
                                @error('category_id')
                                <div class="text-danger">{{$message}}</div>
                                @enderror
                            </div>
                        </div> {{-- end of col category--}}

                        <div class="col-md-4">
                        {{-- date --}}
                        <div class="form-group">
                            <label>Date</label>
                            <input type="datetime-local" name="date" class="form-control" value="{{old('date', $article->date)}}">
                            @error('date')
                            <div class="text-danger">{{$message}}</div>
                            @enderror
                            </div>
                        </div> {{-- end of col date--}}

                    </div> {{-- end of row --}}


                    <div class="row">
                        <div class="col-md-4">
                            {{-- authors --}}
                            <div class="form-group">
                                <label>Authors</label>
                                <select name="author_id" class="form-control select2">
                                    @foreach ($authors as $author)
                                        <option {{ old('author_id',$article->author_id) == $author->id ? "selected" : "" }}  value="{{ $author->id }}">{{ $author->name }}</option>
                                    @endforeach
                                </select>
                                @error('author_id')
                                <div class="text-danger">{{$message}}</div>
                                @enderror
                            </div>
                        </div> {{-- end of col authors--}}

                        <div class="col-md-4">
                            {{-- status --}}
                            <div class="form-group">
                                <label>Status</label>
                                <div class="toggle-flip">
                                    <label><input type="checkbox" value="1" name="status" data-color="success" {{$article->status == '1' ? 'checked' : ''}} >
                                        <span class="flip-indecator" data-toggle-on="Active" data-toggle-off="Not Active"></span>
                                    </label>
                                </div>
                            </div>
                        </div>{{-- end of col status--}}

                        <div class="col-md-4">
                            {{-- image --}}
                            <div class="form-group">
                                <label>Image</label>
                                <input type="file" name="image" class="form-control">
                                @error('image')
                                <div class="text-danger">{{$message}}</div>
                                @enderror
                            </div>
                        </div>{{-- end of col image --}}
                    </div>{{-- end of row --}}


                    <div class="row">
                        {{--Tags--}}
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Tags</label>
                                <select name="tag_id[]" class="form-control select2" multiple>
                                    @foreach ($tags as $tag)
                                        <option {{ old('tag_id',$article->getTagId($article->id,$tag->id)) == $tag->id  ? 'selected':'' }}  value="{{ $tag->id }}">{{ $tag->name }}</option>
                                    @endforeach
                                </select>
                                @error('tag_id')
                                <div class="text-danger">{{$message}}</div>
                                @enderror
                            </div>
                        </div> end of col Tags

                    </div>  {{--end of row --}}

                    <div class="row">
                        <div class="col-md-12">
                            {{-- Description --}}
                            <div class="form-group">
                                <label>Description</label>

                                <textarea id="summernote" class="form-control" name="description"> {!! old('description',$article->description) !!} </textarea>

                                @error('description')
                                <div class="text-danger">{{$message}}</div>
                                @enderror
                            </div>
                        </div> {{-- end of col website--}}


                    </div> {{-- end of row --}}

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i>Update</button>
                    </div>

                </form>

            </div>{{-- end of tile  --}}

        </div> {{-- end of col  --}}
    </div> {{-- end of row  --}}
@endsection
